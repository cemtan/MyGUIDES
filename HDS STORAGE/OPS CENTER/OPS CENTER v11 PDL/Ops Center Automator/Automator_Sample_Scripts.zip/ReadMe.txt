The following two zip files are available.

[SampleCode.zip]
All the sample code files fixed based on the latest specs are included. Note that the sample code files under "uc_create_request_after_input_validation" folder which were originally available in mk-92hc232-00.zip were removed because this use case is no longer available when using the latest service.

[HTML.zip]
The css file (site.css) and Getting+Started.html are included.
For Getting+Started.html, I have just removed the following line because we don't have Index.html:
<p><a href="Index.html">Back to contents</a>

For site.css, I have not modified it at all.
If you want to modify the file name and/or description of html file or css file, please modify these files at your side.
